Summary describing the defect.

## Steps to Reproduce

1.  ...
2.  ...
3.  ...

## Expected Result

...

## Actual Result

...

## Logs & configuration

If applicable, please provide:

- Contents of your `.env` or other configuration files. Keep in mind to remove any sensitive data like password, as the report will be visible publicly.
- Logs: Any errors in your browser console. In Firefox you can reach it by pressing `CTRL + SHIFT + K`, in Chrome or Chromium via `CTRL + SHIFT + J`. If available, extracts of relevant server log files found under `aura/logs`.
- The output of `docker compose ps --all`, ensuring all services are started successfully.

## Environment

Operating system and browser version.
