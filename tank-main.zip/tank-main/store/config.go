//
//  tank, Import and Store Files for AURA
//  Copyright (C) 2017-2020 Christian Pointner <equinox@helsinki.at>
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Affero General Public License as
//  published by the Free Software Foundation, either version 3 of the
//  License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Affero General Public License for more details.
//
//  You should have received a copy of the GNU Affero General Public License
//  along with this program.  If not, see <https://www.gnu.org/licenses/>.
//

package store

import (
	"errors"
	"gorm.io/gorm/logger"
	"net/url"
	"os"
	"strconv"
	"strings"
)

type AudioFormat int

const (
	FormatWAV AudioFormat = iota
	FormatFlac
	FormatUpload
)

func (f AudioFormat) String() string {
	switch f {
	case FormatWAV:
		return "wav"
	case FormatFlac:
		return "flac"
	case FormatUpload:
		return "upload"
	default:
		return "unknown"
	}
}

func (f *AudioFormat) fromString(str string) error {
	switch strings.ToLower(os.ExpandEnv(str)) {
	case "wav":
		*f = FormatWAV
	case "flac":
		*f = FormatFlac
	case "upload":
		*f = FormatUpload
	default:
		return errors.New("invalid audio format: '" + str + "'")
	}
	return nil
}

func (f AudioFormat) MarshalText() (data []byte, err error) {
	data = []byte(f.String())
	return
}

func (f *AudioFormat) UnmarshalText(data []byte) (err error) {
	return f.fromString(string(data))
}

func (f AudioFormat) Extension() string {
	switch f {
	case FormatWAV:
		return ".wav"
	case FormatFlac:
		return ".flac"
	default:
		return ""
	}
}

type AudioConfig struct {
	Format     AudioFormat `json:"format" yaml:"format" toml:"format"`
	SampleRate uint        `json:"sample-rate" yaml:"sample-rate" toml:"sample-rate"`
}

type DBConfig struct {
	Type     string          `json:"type" yaml:"type" toml:"type"`
	Host     string          `json:"host" yaml:"host" toml:"host"`
	Port     uint16          `json:"port" yaml:"port" toml:"port"`
	TLS      string          `json:"tls" yaml:"tls" toml:"tls"`
	Username string          `json:"username" yaml:"username" toml:"username"`
	Password string          `json:"password" yaml:"password" toml:"password"`
	DB       string          `json:"database" yaml:"database" toml:"database"`
	Charset  string          `json:"charset" yaml:"charset" toml:"charset"`
	LogLevel logger.LogLevel `json:"log-level" yaml:"log-level" toml:"log-level"`
}

type Config struct {
	BasePath string      `json:"path" yaml:"path" toml:"path"`
	Audio    AudioConfig `json:"audio" yaml:"audio" toml:"audio"`
	DB       DBConfig    `json:"db" yaml:"db" toml:"db"`
	// TODO: replace DB and DBConfig with a database URL string
}

func (db *DBConfig) ParseDatabaseURL(rawURL string) {
	u, err := url.Parse(rawURL)
	if err != nil {
		panic(err)
	}

	type_ := u.Scheme
	if type_ != "postgres" {
		panic(errors.New("unsupported database type: " + type_))
	}

	port, err := strconv.ParseUint(u.Port(), 10, 16)
	if err != nil {
		panic(err)
	}

	password, _ := u.User.Password() // we don’t care if password is not set

	db.Type = type_
	db.Host = u.Hostname()
	db.Port = uint16(port)
	db.TLS = u.Query().Get("sslmode")
	db.Username = u.User.Username()
	db.Password = password
	db.DB = strings.Trim(u.Path, "/")
}

func (c *Config) ExpandEnv() {
	c.BasePath = os.ExpandEnv(c.BasePath)

	dbURL, isSet := os.LookupEnv("DATABASE_URL")
	if isSet {
		c.DB.ParseDatabaseURL(dbURL)
	} else {
		c.DB.Type = "sqlite3"
	}
}
