//
//  tank, Import and Store Files for AURA
//  Copyright (C) 2017-2020 Christian Pointner <equinox@helsinki.at>
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Affero General Public License as
//  published by the Free Software Foundation, either version 3 of the
//  License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Affero General Public License for more details.
//
//  You should have received a copy of the GNU Affero General Public License
//  along with this program.  If not, see <https://www.gnu.org/licenses/>.
//

package store

import (
	"errors"
	"github.com/go-gormigrate/gormigrate/v2"
	"gorm.io/gorm"
	"time"
)

var (
	dbMigrations = []*gormigrate.Migration{
		{
			ID: "202502171717",
			Migrate: func(tx *gorm.DB) error {
				type Show struct {
					ID        uint64    `json:"id" gorm:"primaryKey"`
					CreatedAt time.Time `json:"created"`
					UpdatedAt time.Time `json:"updated"`
				}
				type FileSource struct {
					URI    string `json:"uri" gorm:"size:1024"`
					Hash   string `json:"hash"`
					Import Import `json:"import" gorm:"embedded;embeddedPrefix:import__"`
				}
				type FileMetadata struct {
					Artist       string `json:"artist,omitempty" gorm:"index"`
					Title        string `json:"title,omitempty" gorm:"index"`
					Album        string `json:"album,omitempty" gorm:"index"`
					Organization string `json:"organization,omitempty" gorm:"index"`
					ISRC         string `json:"isrc,omitempty" gorm:"index"`
				}
				type File struct {
					ID        uint64       `json:"id" gorm:"primaryKey"`
					CreatedAt time.Time    `json:"created"`
					UpdatedAt time.Time    `json:"updated"`
					ShowID    uint64       `json:"showId" gorm:"not null;index"`
					Show      Show         `json:"-" gorm:"associationForeignKey:ID;constraint:OnUpdate:CASCADE,OnDelete:CASCADE"`
					Source    FileSource   `json:"source" gorm:"embedded;embeddedPrefix:source__"`
					Metadata  FileMetadata `json:"metadata" gorm:"embedded;embeddedPrefix:metadata__"`
					Size      uint64       `json:"size"`
					Duration  float64      `json:"duration"`
				}
				type ImportLog struct {
					ID         uint64 `gorm:"primaryKey"`
					File       File   `gorm:"associationAutoUpdate:false;associationAutoCreate:false;constraint:OnUpdate:CASCADE,OnDelete:CASCADE"`
					FileID     uint64 `gorm:"not null;index;uniqueIndex:unique_import_log_step"`
					ImportStep string `gorm:"not null;index;uniqueIndex:unique_import_log_step"`
					Encoded    []byte `gorm:"size:-1"`
				}

				return tx.Migrator().CreateTable(&Show{}, &File{}, &ImportLog{})
			},
			Rollback: func(tx *gorm.DB) error {
				return tx.Migrator().DropTable("shows", "files", "import_logs")
			},
		},
		{
			ID: "202504070707",
			Migrate: func(tx *gorm.DB) error {
				type File struct {
					ID          uint64       `json:"id" gorm:"primaryKey"`
					CreatedAt   time.Time    `json:"created"`
					UpdatedAt   time.Time    `json:"updated"`
					ShowID      uint64       `json:"showId" gorm:"not null;index"`
					Show        Show         `json:"-" gorm:"associationForeignKey:ID;constraint:OnUpdate:CASCADE,OnDelete:CASCADE"`
					Source      FileSource   `json:"source" gorm:"embedded;embeddedPrefix:source__"`
					Metadata    FileMetadata `json:"metadata" gorm:"embedded;embeddedPrefix:metadata__"`
					Size        uint64       `json:"size"`
					Duration    float64      `json:"duration"`
					Description string       `json:"description"`
				}

				return tx.Migrator().AddColumn(File{}, "Description")
			},
			Rollback: func(tx *gorm.DB) error {
				return tx.Migrator().DropColumn(File{}, "Description")
			},
		},
		{
			ID: "2025091111700",
			Migrate: func(tx *gorm.DB) error {
				type File struct {
					ID          uint64       `json:"id" gorm:"primaryKey"`
					CreatedAt   time.Time    `json:"created" swaggertype:"string" format:"date-time"`
					UpdatedAt   time.Time    `json:"updated" swaggertype:"string" format:"date-time"`
					ShowID      uint64       `json:"showId" gorm:"not null;index"`
					Show        Show         `json:"-" gorm:"associationForeignKey:ID;constraint:OnUpdate:CASCADE,OnDelete:CASCADE"`
					Source      FileSource   `json:"source" gorm:"embedded;embeddedPrefix:source__"`
					Metadata    FileMetadata `json:"metadata" gorm:"embedded;embeddedPrefix:metadata__"`
					Size        uint64       `json:"size"`
					Duration    float64      `json:"duration"`
					Description string       `json:"description"`
					Format      string       `json:"format" gorm:"default:''"`
				}

				return tx.Migrator().AddColumn(File{}, "Format")
			},
			Rollback: func(tx *gorm.DB) error {
				return tx.Migrator().DropColumn(File{}, "Format")
			},
		},
	}
)

func (st *Store) initDBModel(cfg DBConfig) (err error) {
	opts := gormigrate.DefaultOptions
	opts.TableName = migrationsTn
	opts.IDColumnSize = 64
	opts.UseTransaction = true

	m := gormigrate.New(st.db, opts, dbMigrations)
	if err = m.Migrate(); err != nil {
		return errors.New("running database migrations failed: " + err.Error())
	}

	if err = st.db.Table(migrationsTn).Select("id").Not("id = ?", "SCHEMA_INIT").Order("id DESC").Limit(1).Row().Scan(&st.revision); err != nil {
		return errors.New("fetching current database revision failed: " + err.Error())
	}
	return
}
