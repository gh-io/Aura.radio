//
//  tank, Import and Store Files for AURA
//  Copyright (C) 2017-2020 Christian Pointner <equinox@helsinki.at>
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Affero General Public License as
//  published by the Free Software Foundation, either version 3 of the
//  License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Affero General Public License for more details.
//
//  You should have received a copy of the GNU Affero General Public License
//  along with this program.  If not, see <https://www.gnu.org/licenses/>.
//

package store

import (
	"context"
	"errors"
	"fmt"
	"gorm.io/driver/postgres"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
	"os"
)

type Store struct {
	revision string
	db       *gorm.DB
	basePath string
	Audio    AudioConfig
}

//
// Initialization and Destruction
//

func postgresConnectionString(cfg DBConfig) (conn string) {
	// "host=127.0.0.1 port=5432 user=tank password=aura dbname=tank sslmode=disable"
	conn = "host=" + cfg.Host
	if cfg.Port > 0 {
		conn += fmt.Sprintf(" port=%d", cfg.Port)
	}
	conn += " user=" + cfg.Username
	if cfg.Password != "" {
		conn += " password=" + cfg.Password
	}
	conn += " dbname=" + cfg.DB
	if cfg.TLS != "" {
		conn += " sslmode=" + cfg.TLS
	}
	return
}

func openDB(cfg DBConfig) (db *gorm.DB, err error) {
	switch cfg.Type {
	case "postgres":
		conn := postgresConnectionString(cfg)
		if db, err = gorm.Open(postgres.Open(conn), &gorm.Config{Logger: logger.Default.LogMode(cfg.LogLevel)}); err != nil {
			return nil, errors.New("failed to connect to database: " + err.Error())
		}
	case "sqlite3":
		if db, err = gorm.Open(sqlite.Open("/tmp/db.sqlite3"), &gorm.Config{}); err != nil {
			return nil, errors.New("failed to open database: " + err.Error())
		}
	default:
		return nil, errors.New("unknown database engine: " + cfg.Type)
	}

	sqlDB, err := db.DB()
	if sqlDB.Ping() != nil {
		return nil, errors.New("gorm.Ping(): " + err.Error())
	}

	return
}

func NewStore(cfg Config) (*Store, error) {
	if _, err := os.Stat(cfg.BasePath); err != nil {
		return nil, errors.New("can't open store's base path: " + err.Error())
	}

	db, err := openDB(cfg.DB)
	if err != nil {
		return nil, err
	}

	st := &Store{"", db, cfg.BasePath, cfg.Audio}
	if err = st.initDBModel(cfg.DB); err != nil {
		return nil, err
	}

	return st, nil
}

func (st *Store) Healthz(ctx context.Context) error {
	sqlDB, err := st.db.DB()
	if sqlDB.Ping() != nil {
		return errors.New("gorm.Ping(): " + err.Error())
	}

	return err
}

func (st *Store) GetRevision() string {
	return st.revision
}

func (st *Store) Close() {
	sqlDB, _ := st.db.DB()
	_ = sqlDB.Close() // dear linter: we are deliberately not handling errors from Close(), we can't do anything about it anyway
}
