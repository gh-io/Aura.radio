//
//  tank, Import and Store Files for AURA
//  Copyright (C) 2017-2020 Christian Pointner <equinox@helsinki.at>
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Affero General Public License as
//  published by the Free Software Foundation, either version 3 of the
//  License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Affero General Public License for more details.
//
//  You should have received a copy of the GNU Affero General Public License
//  along with this program.  If not, see <https://www.gnu.org/licenses/>.
//

package store

import (
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strconv"

	"gorm.io/gorm"
)

type DeleteCounter struct {
	Files      int64 `json:"files"`
	ImportLogs int64 `json:"importLogs"`
	Shows      int64 `json:"shows"`
}

func (st *Store) getShowPath(showID uint64) string {
	return filepath.Join(st.basePath, strconv.FormatUint(showID, 10))
}

func (st *Store) createShow(tx *gorm.DB, showID uint64) (show *Show, err error) {
	showDirPath := st.getShowPath(showID)
	if err := os.Mkdir(showDirPath, 0755); err != nil {
		if !os.IsExist(err) {
			return nil, errors.New("unable to create directory for show '" + filepath.Join(st.basePath, strconv.FormatUint(showID, 10)) + "': " + err.Error())
		}
		if stat, err := os.Stat(showDirPath); err != nil {
			return nil, errors.New("unable to get FileInfo for directory '" + filepath.Join(st.basePath, strconv.FormatUint(showID, 10)) + "': " + err.Error())
		} else if !stat.IsDir() {
			return nil, errors.New("path exists and is not a directory '" + filepath.Join(st.basePath, strconv.FormatUint(showID, 10)))
		}
	}
	show = &Show{ID: showID}
	err = tx.FirstOrCreate(show).Error
	if err != nil {
		_ = os.RemoveAll(showDirPath) // dear linter: we are deliberately not handling errors from RemoveAll()
	}
	return
}

// this will not fail if the show already exists
func (st *Store) CreateShow(name uint64) (show *Show, err error) {
	return st.createShow(st.db, name)
}

func (st *Store) cloneFiles(tx *gorm.DB, showID, from uint64) (fileIDMapping map[uint64]uint64, err error) {
	fileIDMapping = make(map[uint64]uint64)
	var files []File
	if err = tx.Where("show_id = ?", from).Find(&files).Error; err != nil {
		return
	}
	for _, file := range files {
		fromFileID := file.ID

		file.ID = 0
		file.ShowID = showID
		if err = tx.Create(&file).Error; err != nil {
			return
		}
		if err = os.Link(st.GetFilePath(from, fromFileID, ""), st.GetFilePath(showID, file.ID, "")); err != nil {
			return
		}
		fileIDMapping[fromFileID] = file.ID

		var logs []ImportLog
		if err = tx.Where("file_id = ?", file.ID).Find(&logs).Error; err != nil {
			return
		}
		for _, log := range logs {
			log.ID = 0
			log.File = File{ID: file.ID, ShowID: showID}
			log.FileID = 0
			if err = tx.Create(&log).Error; err != nil {
				return
			}
		}
	}
	return
}

func (st *Store) CloneShow(name, from uint64) (show *Show, err error) {
	tx := st.db.Begin()
	defer func() {
		if r := recover(); r != nil {
			tx.Rollback()
			_ = os.RemoveAll(st.getShowPath(name)) // dear linter: we are deliberately not handling errors from RemoveAll()
			if err == nil {
				err = fmt.Errorf("runtime panic: %+v", r)
			}
		}
	}()
	if err = tx.Error; err != nil {
		return
	}

	cnt := int64(0)
	if err = tx.Model(&Show{ID: from}).Count(&cnt).Error; err != nil {
		tx.Rollback()
		return
	}
	if cnt == 0 {
		tx.Rollback()
		err = ErrNotFound
		return
	}
	if err = tx.Model(&Show{ID: name}).Count(&cnt).Error; err != nil {
		tx.Rollback()
		return
	}
	if cnt > 0 {
		tx.Rollback()
		err = ErrShowAlreadyExists
		return
	}

	if show, err = st.createShow(tx, name); err != nil {
		tx.Rollback()
		return
	}
	if _, err = st.cloneFiles(tx, name, from); err != nil {
		tx.Rollback()
		_ = os.RemoveAll(st.getShowPath(name)) // dear linter: we are deliberately not handling errors from RemoveAll()
		return
	}

	err = tx.Commit().Error
	return
}

// this will also remove all files and playlists belonging to the show!
func (st *Store) DeleteShow(showID uint64) (err error) {
	tx := st.db.Begin()
	defer func() {
		if r := recover(); r != nil {
			tx.Rollback()
			if err == nil {
				err = fmt.Errorf("runtime panic: %+v", r)
			}
		}
	}()
	if err = tx.Error; err != nil {
		return
	}

	// deleting the show will cascade to delete the files as well.
	if err = tx.Delete(&Show{ID: showID}).Error; err != nil {
		tx.Rollback()
		return
	}
	if err = os.RemoveAll(st.getShowPath(showID)); err != nil {
		tx.Rollback()
		return
	}

	err = tx.Commit().Error
	return
}

func (st *Store) ListShows() (shows []Show, err error) {
	err = st.db.Find(&shows).Error
	return
}

func removeDirectories(path string) (err error) {
	dirs, err := filepath.Glob(path)

	if err != nil {
		return
	}

	for _, dir := range dirs {
		err = os.RemoveAll(dir)

		if err != nil {
			return
		}
	}

	return
}

func (st *Store) ResetState() (deleteCounter DeleteCounter, err error) {
	importLogs := st.db.Exec("DELETE FROM import_logs").RowsAffected
	files := st.db.Exec("DELETE FROM files").RowsAffected
	shows := st.db.Exec("DELETE FROM shows").RowsAffected

	err = removeDirectories(filepath.Join(st.basePath, "*"))

	return DeleteCounter{Files: files, ImportLogs: importLogs, Shows: shows}, err
}
