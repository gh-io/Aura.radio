//
//  tank, Import and Store Files for AURA
//  Copyright (C) 2017-2020 Christian Pointner <equinox@helsinki.at>
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Affero General Public License as
//  published by the Free Software Foundation, either version 3 of the
//  License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Affero General Public License for more details.
//
//  You should have received a copy of the GNU Affero General Public License
//  along with this program.  If not, see <https://www.gnu.org/licenses/>.
//

package store

import (
	"fmt"
	"io"
	"os"
	"os/user"
	"path/filepath"
	"reflect"
	"strconv"
	"testing"
	//"github.com/jinzhu/gorm"
)

var (
	testBasePath    = "run/aura-tank_testing"
	testShowID      = uint64(42)
	testTestDirPath = filepath.Join(testBasePath, strconv.FormatUint(testShowID, 10))
	testDBPort      = uint16(0)
	testDBUsername  = "tank"
	testDBPassword  = "aura"
	testDBDB        = "tank"

	testShow1       = uint64(1)
	testShow2       = uint64(2)
	testSourceURI1  = "upload://test1.mp3"
	testSourceURI2  = "upload://test2.ogg"
	testFileArtist1 = "solo artist"
	testFileArtist2 = "band of 2"
	testFileAlbum1  = "first album"
	testFileAlbum2  = "second album"
	testFileTitle1  = "this is one title"
	testFileTitle2  = "this is not two title's"
)

func testDBConfig() (cfg DBConfig) {
	cfg.Type = os.Getenv("AURA_TANK_TEST_DB_TYPE")
	cfg.Host = os.Getenv("AURA_TANK_TEST_DB_HOST")
	if cfg.Host == "" {
		cfg.Host = "127.0.0.1"
	}
	switch cfg.Type {
	case "postgres":
		cfg.TLS = "disable"
	}

	cfg.Port = testDBPort
	cfg.Username = testDBUsername
	cfg.Password = testDBPassword
	cfg.DB = testDBDB
	return
}

func newTestStore(t *testing.T) *Store {
	cfg := Config{}
	cfg.BasePath = testBasePath
	cfg.DB = testDBConfig()

	// TODO: drop database (all tables and constrains)

	store, err := NewStore(cfg)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	return store
}

func TestMain(m *testing.M) {
	u, err := user.Current()
	if err != nil {
		os.Exit(-1)
	}
	testBasePath = fmt.Sprintf("/run/user/%s/aura-tank_testing", u.Uid)
	err = os.RemoveAll(testBasePath)
	if err != nil {
		os.Exit(-1)
	}
	testTestDirPath = filepath.Join(testBasePath, strconv.FormatUint(testShowID, 10))
	os.Exit(m.Run())
}

//
// Testing
//

func TestOpen(t *testing.T) {
	// base-path is non-existing directory
	cfg := Config{}
	cfg.BasePath = "/nonexistend/"
	cfg.DB = testDBConfig()
	if _, err := NewStore(cfg); err == nil {
		t.Fatalf("opening store in nonexisting directory should throw an error")
	}
	cfg.BasePath = testBasePath
	if err := os.MkdirAll(testBasePath, 0700); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	store, err := NewStore(cfg)
	if err != nil {
		t.Fatalf("creating new store failed: %v", err)
	}
	store.Close()

	if store, err = NewStore(cfg); err != nil {
		t.Fatalf("re-opening existing store failed: %v", err)
	}
	store.Close()

	if err := os.RemoveAll(testTestDirPath); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
}

func TestMigrations(t *testing.T) {
	cfg := Config{}
	cfg.BasePath = testBasePath
	cfg.DB = testDBConfig()

	// os.Remove(testDBConnection)
	store, err := NewStore(cfg)
	if err != nil {
		t.Fatalf("creating new store failed: %v", err)
	}

	expected := dbMigrations[len(dbMigrations)-1].ID
	if store.GetRevision() != expected {
		t.Fatalf("for now new databases should have revision %q: got %q", expected, store.GetRevision())
	}
	store.Close()
	// TODO: needs more testing!!!!
}

//// Arrrrgh!!!!!
////  both database/sql and gorm are incredibly stupid!!!!
////  using database/sql alone it is needlessly hard to write portable sql queries:
////     postgres: db.Exec("INSERT INTO shows (name) VALUES ($1)", testShow1)
////     mysql:    db.Exec("INSERT INTO shows (name) VALUES (?)", testShow1)
////
////  using gorm db.Exec() will deal with that but i couldn't find a good way to get
////     the last inserted id without using the model code of gorm and we specifically
////     don't want to use the model code since it is not clear whether the constraints
////     are actually enforced by the DBMS or by some gorm callbacks...
////
// func TestDBConstraints(t *testing.T) {
// 	// we don't want to use the model but hand written SQL commands here since we want to check
// 	// whether the constraints are really enforced by the DBMS and not by some magic bullshit in gorm!
//  // This is even worse since gorm.AutoUpdate will not deal with foreign key constraints and we
//  // need do it ourselves at the migration scripts. It would be really nice to be able to check
//  // whether the migrations do the right thing!!!

// 	db, err := gorm.Open(testDBType, testDBConnection)
// 	if err != nil {
// 		t.Fatalf("unexpected error: %v", err)
// 	}
// 	if err = db.DB().Ping(); err != nil {
// 		t.Fatalf("unexpected error: %v", err)
// 	}

// 	res := db.Exec("INSERT INTO shows (name) VALUES (?)", testShow1)
// 	if res.Error != nil {
// 		t.Fatalf("adding show '%s' shouldn't fail: %v", testShow1, res.Error)
// 	}
// 	if res = db.Exec("INSERT INTO shows (name) VALUES (?)", testShow1); res.Error == nil {
// 		t.Fatalf("re-adding the same show should fail")
// 	}

// 	if res = db.Exec("INSERT INTO files (show_name, size) VALUES (?, ?)", testShow1, 500); res.Error != nil {
// 		t.Fatalf("re-adding the same show should fail")
// 	}
// }

// Shows
//

func checkShows(t *testing.T, shows []Show, expected []uint64) {
	// if len(shows) != len(expected) {
	// 	t.Fatalf("expected %d shows in store but got %d: %v", len(expected), len(shows), shows)
	// }
	for _, sid := range expected {
		found := false
		for _, g := range shows {
			if sid == g.ID {
				found = true
				break
			}
		}
		if !found {
			t.Fatalf("expected show '%c' to be in store but got: %v", sid, shows)
		}
		if st, err := os.Stat(filepath.Join(testBasePath, strconv.FormatUint(sid, 10))); err != nil {
			t.Fatalf("can't open show directory for show '%d': %v", sid, err)
		} else if !st.IsDir() {
			t.Fatalf("path of show '%d' is not a directory", sid)
		}
	}
}

func TestShows(t *testing.T) {
	store := newTestStore(t)

	shows, err := store.ListShows()
	if err != nil {
		t.Fatalf("listing shows failed: %v", err)
	}
	checkShows(t, shows, []uint64{})

	if f, err := os.Create(testTestDirPath); err != nil {
		t.Fatalf("unexpected error: %v", err)
	} else {
		_, err := io.WriteString(f, "this is not a directory")
		if err != nil {
			t.Fatalf("unexpected error: %v", err)
		}
		err = f.Close()
		if err != nil {
			t.Fatalf("unexpected error: %v", err)
		}
	}
	if _, err = store.CreateShow(testShowID); err == nil {
		t.Fatalf("creating a show where dir exists but is not a directory should throw an error")
	}
	if err := os.RemoveAll(testTestDirPath); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	if _, err = store.CreateShow(testShow1); err != nil {
		t.Fatalf("creating show failed: %v", err)
	}
	if _, err = store.CreateShow(testShow2); err != nil {
		t.Fatalf("creating show failed: %v", err)
	}

	shows, err = store.ListShows()
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	checkShows(t, shows, []uint64{testShow1, testShow2})

	if err = store.DeleteShow(testShow1); err != nil {
		t.Fatalf("deleting show '%d' failed: %v", testShow1, err)
	}

	shows, err = store.ListShows()
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	checkShows(t, shows, []uint64{testShow2})

	if err = store.DeleteShow(testShow2); err != nil {
		t.Fatalf("deleting show '%d' failed: %v", testShow2, err)
	}
	checkShows(t, shows, []uint64{})
}

// Files
//

func TestFilesListCreateDelete(t *testing.T) {
	store := newTestStore(t)

	files, err := store.ListFiles(testShowID, -1, -1)
	if err != nil {
		t.Fatalf("listing files of test show failed: %v", err)
	}
	if len(files) != 0 {
		t.Fatalf("a newly created store should contain no files in test show but ListFiles returned: %v", files)
	}

	files, err = store.ListFiles(uint64(0), -1, -1)
	if err != nil {
		t.Fatalf("listing files of not existing show shouldn't throw an error but returned: %v", err)
	}
	if len(files) != 0 {
		t.Fatalf("listing files of not existing show should return and empty list but ListFiles returned: %v", files)
	}

	testFile, err := store.CreateFile(testShowID, "", File{})
	if err != nil {
		t.Fatalf("creating file in test show failed: %v", err)
	}

	files, err = store.ListFiles(testShowID, -1, -1)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(files) != 1 {
		t.Fatalf("ListFiles should return a single file but returned: %v", files)
	}
	_, err = store.CreateFile(testShow1, "", File{Size: 17})
	if err != nil {
		t.Fatalf("creating file in not existing show shouldn't throw an error but CreateFile returned: %v", err)
	}
	_, err = store.CreateFile(testShow1, "", File{Size: 23})
	if err != nil {
		t.Fatalf("creating file in not existing show shouldn't throw an error but CreateFile returned: %v", err)
	}

	shows, err := store.ListShows()
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	checkShows(t, shows, []uint64{testShowID, testShow1})

	files, err = store.ListFiles(testShow1, -1, -1)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(files) != 2 {
		t.Fatalf("ListFiles should return a two files  but returned: %v", files)
	}

	// clean up so next test can run with a clean DB, TODO: remove as soon as newTestStore() can re-init the DB
	if err = store.DeleteShow(testShow1); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	if err = store.DeleteFile(testShowID, testFile.ID); err != nil {
		t.Fatalf("deleting file %d of show '%d' failed: %v", testFile.ID, testShowID, err)
	}
	checkShows(t, shows, []uint64{testShowID})
}

func fileEqual(a, b *File) bool {
	// TODO: comparing the whole file struct using DeepEqual does not work because it does not use time.Equal when comparing timestamps...
	return a.Size == b.Size || reflect.DeepEqual(a.Source, b.Source) || reflect.DeepEqual(a.Metadata, b.Metadata)
}

func TestFilesCreateAndGet(t *testing.T) {
	store := newTestStore(t)

	if _, err := store.GetFile(testShow1, 0); err != ErrNotFound {
		t.Fatalf("getting file in not-existing show should return ErrNotFound, but GetFile returned: %v", err)
	}

	file1 := File{Size: 12345}
	file1.Source.URI = testSourceURI1
	file1.Metadata.Artist = testFileArtist1
	file1.Metadata.Album = testFileAlbum1
	file1.Metadata.Title = testFileTitle1
	in1, err := store.CreateFile(testShow1, "", file1)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	out1, err := store.GetFile(testShow1, in1.ID)
	if err != nil {
		t.Fatalf("getting existing file from store shouldn't return an error, but GetFile returned: %v", err)
	}
	if !fileEqual(in1, out1) {
		t.Fatalf("GetFile returned different file than expected. Got %+v, expected %+v", out1, in1)
	}

	if _, err = store.GetFile(testShow1, 0); err != ErrNotFound {
		t.Fatalf("getting not-existing file in existing show should return ErrNotFound, but GetFile returned: %v", err)
	}

	file2 := File{Size: 54321}
	file2.Source.URI = testSourceURI2
	file2.Metadata.Artist = testFileArtist2
	file2.Metadata.Album = testFileAlbum2
	file2.Metadata.Title = testFileTitle2
	in2, err := store.CreateFile(testShow1, "", file2)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	out2, err := store.GetFile(testShow1, in2.ID)
	if err != nil {
		t.Fatalf("getting existing file from store shouldn't return an error, but GetFile returned: %v", err)
	}
	if !fileEqual(in2, out2) {
		t.Fatalf("GetFile returned different file than expected. Got %+v, expected %+v", out2, in2)
	}

	files, err := store.ListFiles(testShow1, -1, -1)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(files) != 2 {
		t.Fatalf("show '%d' should contain 2 files but ListFiles returned: %+v", testShow1, files)
	}
	for _, file := range files {
		if file.ID == in1.ID {
			if !fileEqual(in1, out1) {
				t.Fatalf("ListFile returned different file than expected. Got %+v, expected %+v", out1, in1)
			}
		} else if file.ID == in2.ID {
			if !fileEqual(in2, out2) {
				t.Fatalf("ListFile returned different file than expected. Got %+v, expected %+v", out2, in2)
			}
		} else {
			t.Fatalf("show '%d' should only contain files %d and %d but ListFiles returned: %+v", testShow1, in1.ID, in2.ID, files)
		}
	}

	// clean up so next test can run with a clean DB, TODO: remove as soon as newTestStore() can re-init the DB
	if err = store.DeleteShow(testShow1); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
}

// TODO: add test for pagination in store.ListeFiles()

func TestFilesUpdate(t *testing.T) {
	store := newTestStore(t)

	if _, err := store.UpdateFile(testShowID, 0, File{}); err != ErrNotFound {
		t.Fatalf("updateting not-existing file should return ErrNotFound, but UpdateFile returned: %v", err)
	}

	file := File{Size: 12345}
	file.Source.URI = testSourceURI1
	file.Metadata.Artist = testFileArtist1
	file.Metadata.Album = testFileAlbum1
	file.Metadata.Title = testFileTitle1
	in, err := store.CreateFile(testShow2, "", file)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	out, err := store.GetFile(testShow2, in.ID)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if !fileEqual(in, out) {
		t.Fatalf("GetFile returned different file than expected. Got %+v, expected %+v", out, in)
	}

	out.Size = 54321
	out.Source.URI = testSourceURI2
	out.Metadata.Artist = testFileArtist2
	out.Metadata.Album = testFileAlbum2
	out.Metadata.Title = testFileTitle2
	if _, err = store.UpdateFile(testShow2, in.ID, *out); err != nil {
		t.Fatalf("updateting an existing file shouldn't fail but UpdateFile returned: %v", err)
	}

	files, err := store.ListFiles(testShow2, -1, -1)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if len(files) != 1 {
		t.Fatalf("show '%d' should contain 1 file but ListFiles returned: %+v", testShow2, files)
	}
	if files[0].ID != in.ID || !fileEqual(out, &(files[0])) {
		t.Fatalf("ListFile returned different file than expected. Got %+v, expected %+v", out, files[0])
	}

	// clean up so next test can run with a clean DB, TODO: remove as soon as newTestStore() can re-init the DB
	if err = store.DeleteShow(testShow2); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
}

func TestFilesDelete(t *testing.T) {
	store := newTestStore(t)

	if err := store.DeleteFile(testShow1, 0); err != ErrNotFound {
		t.Fatalf("deleting not-existing file should return ErrNotFound, but DeleteFile returned: %v", err)
	}

	file, err := store.CreateFile(testShow1, "", File{Size: 12345})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	if err = store.DeleteFile(testShow1, file.ID); err != nil {
		t.Fatalf("deleting file failed, DeleteFile returned: %v", err)
	}

	if err = store.DeleteFile(testShow1, file.ID); err != ErrNotFound {
		t.Fatalf("repeated deletion of file should return ErrNotFound, but DeleteFile returned: %v", err)
	}

	// clean up so next test can run with a clean DB, TODO: remove as soon as newTestStore() can re-init the DB
	if err = store.DeleteShow(testShow1); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
}

func TestFilesImportState(t *testing.T) {
	store := newTestStore(t)

	file, err := store.CreateFile(testShow1, "", File{})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	if file.Source.Import.State != ImportNew {
		t.Fatalf("newly created file should have state %q but has %q", ImportNew, file.Source.Import.State)
	}

	if _, err = store.SetFileImportStateInitializing(file.ShowID, file.ID); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	if _, err = store.SetFileImportStateInitializing(file.ShowID, file.ID); err != ErrFileNotNew {
		t.Fatalf("setting file import state to %q for file that is not new must fail with ErrFileNotNew but got: %v", ImportInitializing, err)
	}

	if file, err = store.SetFileImportStatePending(file.ShowID, file.ID); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if file.Source.Import.State != ImportPending {
		t.Fatalf("file should now have state %q but has %q", ImportPending, file.Source.Import.State)
	}

	if file, err = store.SetFileImportStateRunning(file.ShowID, file.ID); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if file.Source.Import.State != ImportRunning {
		t.Fatalf("file should now have state %q but has %q", ImportRunning, file.Source.Import.State)
	}

	// TODO: testing done needs some extra work since the store will try to read the metadata from the file

	if file, err = store.SetFileImportStateAborted(file.ShowID, file.ID, "computer says noooo..."); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	// FIXME: https://gitlab.servus.at/aura/tank/-/issues/82
	//if file.Source.Import.State != ImportAborted {
	//	t.Fatalf("file should now have state %q but has %q", ImportAborted, file.Source.Import.State)
	//}
	if file.Source.Import.Error != "computer says noooo..." {
		t.Fatalf("file import error is wrong: %q", file.Source.Import.Error)
	}

}

func TestFilesSourceHash(t *testing.T) {
	store := newTestStore(t)

	file, err := store.CreateFile(testShow1, "", File{})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	if file.Source.Hash != "" {
		t.Fatalf("new file should have no hash set but has: %q", file.Source.Hash)
	}

	hash := "this-is-the-output-of-a-hash-function"
	if file, err = store.UpdateFileSourceHash(file.ShowID, file.ID, hash); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	if file.Source.Hash != hash {
		t.Fatalf("file should now have hash set to %q but has %q", hash, file.Source.Hash)
	}
}
