//
//  tank, Import and Store Files for AURA
//  Copyright (C) 2017-2020 Christian Pointner <equinox@helsinki.at>
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Affero General Public License as
//  published by the Free Software Foundation, either version 3 of the
//  License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Affero General Public License for more details.
//
//  You should have received a copy of the GNU Affero General Public License
//  along with this program.  If not, see <https://www.gnu.org/licenses/>.
//

package store

import (
	"fmt"
	"os"
	"path/filepath"
)

// GetFilePath returns the path for/of a file, based on the show ID, the file ID and the source of the file
func (st *Store) GetFilePath(showID uint64, fileID uint64, source string) string {
	var format string

	if source == "" {
		// the file is already stored
		format, _ = st.GetFileFormat(fileID)
	} else if st.Audio.Format.String() == "upload" {
		format = filepath.Ext(source)[1:]
	} else {
		format = st.Audio.Format.String()
	}

	return filepath.Join(st.getShowPath(showID), fmt.Sprintf("%d.%s", fileID, format))
}

func (st *Store) ListFiles(showID uint64, offset, limit int) (files []File, err error) {
	err = st.db.Where("show_id = ?", showID).Order("id").Limit(limit).Offset(offset).Find(&files).Error
	return
}

func (st *Store) CreateFile(showID uint64, description string, file File) (*File, error) {
	if _, err := st.CreateShow(showID); err != nil {
		return nil, err
	}
	file.ID = 0
	file.ShowID = showID
	file.Description = description

	if st.Audio.Format.String() == "upload" {
		file.Format = filepath.Ext(file.Source.URI)[1:]
	} else {
		file.Format = st.Audio.Format.String()
	}

	err := st.db.Create(&file).Error
	return &file, err
}

func (st *Store) GetFile(showID uint64, fileID uint64) (file *File, err error) {
	file = &File{}
	// we have to make sure that the file actually belongs to <show> since permissions are enforced
	// based on show membership
	err = st.db.Where("show_id = ?", showID).First(file, fileID).Error
	return
}

func (st *Store) GetFiles(fileIds []uint64, offset, limit int) (files []File, err error) {
	// we don’t care who owns the files
	err = st.db.Where("id in ?", fileIds).Order("id").Limit(limit).Offset(offset).Find(&files).Error

	return
}

func (st *Store) UpdateFile(showID uint64, id uint64, file File) (out *File, err error) {
	tx := st.db.Begin()
	defer func() {
		if r := recover(); r != nil {
			tx.Rollback()
			if err == nil {
				err = fmt.Errorf("runtime panic: %+v", r)
			}
		}
	}()
	if err = tx.Error; err != nil {
		return
	}

	// make sure the file exists and actually belongs to <show> since permissions are enforced
	// based on show membership
	if err = tx.Where("show_id = ?", showID).First(&File{}, id).Error; err != nil {
		tx.Rollback()
		return
	}

	file.ID = id
	file.ShowID = showID
	if err = tx.Save(&file).Error; err != nil {
		tx.Rollback()
		return
	}
	err = tx.Commit().Error
	out = &file
	return
}

func (st *Store) UpdateFileMetadata(showID uint64, id uint64, metadata map[string]string) (file *File, err error) {
	tx := st.db.Begin()
	defer func() {
		if r := recover(); r != nil {
			tx.Rollback()
			if err == nil {
				err = fmt.Errorf("runtime panic: %+v", r)
			}
		}
	}()
	if err = tx.Error; err != nil {
		return
	}

	file = &File{ID: id}
	// make sure the file exists and actually belongs to <show> since permissions are enforced
	// based on show membership
	if err = tx.Where("show_id = ?", showID).First(&file).Error; err != nil {
		tx.Rollback()
		return
	}
	if file.Source.Import.State != ImportDone {
		tx.Rollback()
		err = ErrFileImportNotDone
		return
	}

	var fields map[string]interface{}
	if fields, err = st.metadataFieldsToFile(showID, id, metadata); err != nil {
		tx.Rollback()
		return
	}
	if err = tx.Model(&file).Where("show_id = ?", showID).Updates(fields).Error; err != nil {
		tx.Rollback()
		return
	}
	err = tx.Commit().Error
	return
}

func (st *Store) updateImportState(showID uint64, id uint64, state ImportState) (file *File, err error) {
	file = &File{ID: id}

	if err = st.db.Model(&file).Where("show_id = ?", showID).Update("source__import__state", state).Error; err != nil {
		return nil, err
	}

	return file, nil
}

func (st *Store) updateImportError(showID uint64, id uint64, error string) (file *File, err error) {
	file = &File{ID: id}

	if err = st.db.Model(&file).Where("show_id = ?", showID).Update("source__import__error", error).Error; err != nil {
		return nil, err
	}

	return file, nil
}

func (st *Store) updateHash(showID uint64, id uint64, hash string) (file *File, err error) {
	file = &File{ID: id}

	if err = st.db.Model(&file).Where("show_id = ?", showID).Update("source__hash", hash).Error; err != nil {
		return nil, err
	}

	return file, nil
}

func (st *Store) updateMetadata(showID, id uint64, metadata map[string]interface{}) (file *File, err error) {
	file = &File{ID: id}

	// we need to select all the fields with "*" to update them using this function
	if err = st.db.Model(&file).Where("show_id = ?", showID).Select("*").Updates(metadata).Error; err != nil {
		return nil, err
	}

	return file, nil
}

func (st *Store) SetFileImportStateInitializing(showID uint64, id uint64) (file *File, err error) {
	file = &File{ID: id}
	result := st.db.Model(&file).Where("show_id = ? and source__import__state = ?", showID, ImportNew).Update("source__import__state", ImportInitializing)
	if result.Error != nil {
		return nil, result.Error
	}
	if result.RowsAffected != 1 {
		return nil, ErrFileNotNew
	}

	return file, nil
}

func (st *Store) SetFileImportStatePending(showID uint64, id uint64) (file *File, err error) {
	return st.updateImportState(showID, id, ImportPending)
}

func (st *Store) SetFileImportStateRunning(showID uint64, id uint64) (file *File, err error) {
	return st.updateImportState(showID, id, ImportRunning)
}

func (st *Store) SetFileImportStateDone(showID uint64, id uint64) (file *File, err error) {
	if file, err = st.updateImportState(showID, id, ImportDone); err != nil {
		return nil, err
	}

	fields, err := st.metadataFieldsFromFile(showID, id)
	if err != nil {
		return nil, err
	}

	return st.updateMetadata(showID, id, fields)
}

func (st *Store) SetFileImportStateAborted(showID uint64, id uint64, error string) (file *File, err error) {
	if file, err = st.updateImportState(showID, id, ImportAborted); err != nil {
		return nil, err
	}

	return st.updateImportError(showID, id, error)
}

func (st *Store) UpdateFileSourceHash(showID uint64, id uint64, hash string) (file *File, err error) {
	return st.updateHash(showID, id, hash)
}

func (st *Store) DeleteFile(showID uint64, id uint64) (err error) {
	// make sure the file actually belongs to <show> since permissions are enforced
	// based on show membership
	result := st.db.Where("show_id = ?", showID).Where("id = ?", id).Delete(File{})
	if err = result.Error; err != nil {
		return
	}
	if result.RowsAffected == 0 {
		return ErrNotFound
	}

	filename := st.GetFilePath(showID, id, "")
	if err := os.Remove(filename); err != nil && !os.IsNotExist(err) {
		return fmt.Errorf("unable to delete file '%s': %v", filename, err)
	}
	return
}

func (st *Store) GetFileShowID(id uint64) (uint64, error) {
	// WARNING: using this function subverts the checks performed in the other functions
	file := &File{}
	if err := st.db.First(file, "id = ?", id).Error; err != nil {
		return 0, err
	}
	return file.ShowID, nil
}

// GetFileFormat returns the format of the file. It returns the configured audio format the field is empty
func (st *Store) GetFileFormat(id uint64) (string, error) {
	file := &File{}
	var format string

	if err := st.db.First(file, "id = ?", id).Error; err != nil {
		return "", err
	}

	if file.Format == "" {
		format = st.Audio.Format.String()
	} else {
		format = file.Format
	}

	return format, nil
}
