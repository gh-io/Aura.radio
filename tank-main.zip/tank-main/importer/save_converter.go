//
//  tank, Import and Store Files for AURA
//  Copyright (C) 2025 Ernesto Rico Schmidt <ernesto@helsinki.at>
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Affero General Public License as
//  published by the Free Software Foundation, either version 3 of the
//  License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Affero General Public License for more details.
//
//  You should have received a copy of the GNU Affero General Public License
//  along with this program.  If not, see <https://www.gnu.org/licenses/>.
//

package importer

import (
	"gitlab.servus.at/autoradio/tank/store"
	"io"
	"os"
)

type saveConverter interface {
	io.WriteCloser
	Wait() (log *store.Log, err error)
}

func (job *Job) newSaveConverter() (saveConverter, error) {
	return newFetchSaver(job)
}

type fetchSaver struct {
	job   *Job
	file  *os.File
	log   *store.Log
	stdin io.WriteCloser
}

func newFetchSaver(job *Job) (s *fetchSaver, err error) {
	s = &fetchSaver{job: job}
	s.log = &store.Log{}
	filename := job.im.store.GetFilePath(job.ShowID, job.ID, job.Source.String())

	job.im.dbgLog.Printf("fetch-saver: openin file '%s'", filename)

	if s.file, err = os.OpenFile(filename, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600); err != nil {
		s.log.Append("stderr", "ERROR opening file failed: "+err.Error())
		return
	}

	if deadline, ok := job.Ctx.Deadline(); ok {
		_ = s.file.SetDeadline(deadline)
	}

	job.im.dbgLog.Printf("fetch-saver: succesfully opened file '%s'", filename)
	s.log.Append("stdout", "successfully opened file: "+filename)

	return
}

func (s *fetchSaver) Write(p []byte) (n int, err error) {
	return s.file.Write(p)
}

func (s *fetchSaver) Close() (err error) {
	return s.file.Close()
}

func (s *fetchSaver) Wait() (log *store.Log, err error) {
	return s.log, nil
}
