//
//  tank, Import and Store Files for AURA
//  Copyright (C) 2025 Ernesto Rico Schmidt <ernesto@helsinki.at>
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Affero General Public License as
//  published by the Free Software Foundation, either version 3 of the
//  License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Affero General Public License for more details.
//
//  You should have received a copy of the GNU Affero General Public License
//  along with this program.  If not, see <https://www.gnu.org/licenses/>.
//

package importer

import (
	"io"
	"os"
	"path/filepath"
)

func (job *Job) copyToSave(w io.Writer, done chan<- error) {
	defer close(done)

	src, err := os.OpenFile(filepath.Join(job.WorkDir, "source"), os.O_RDONLY, 0400)
	if err != nil {
		done <- err
		return
	}
	srcStat, err := src.Stat()
	if err != nil {
		done <- err
		return
	}
	if deadline, ok := job.Ctx.Deadline(); ok {
		_ = src.SetDeadline(deadline) // this will probably fail but we try it anyway
	}

	written, err := io.Copy(&progressWriter{job, StepSaving, uint64(srcStat.Size()), 0, w}, src)
	if err != nil {
		done <- err
		return
	}
	job.im.dbgLog.Printf("save(): done copying %d bytes from source", written)
}

func (job *Job) save() error {
	job.Progress.set(StepSaving, 0)

	conv, err := job.newSaveConverter()
	if err != nil {
		job.im.errLog.Printf("save(): creating converter failed: %v", err)
		return err
	}

	done := make(chan error)
	go job.copyToSave(conv, done)

	select {
	case <-job.Ctx.Done():
		conv.Close()
		go conv.Wait()
		return job.Ctx.Err()
	case err = <-done:
	}

	conv.Close()
	convLog, convErr := conv.Wait()
	job.im.dbgLog.Printf("save(): converter returned: %v", err)
	if err == nil {
		err = convErr
	}

	if err := job.im.store.AddImportLog(job.ShowID, job.ID, "save", convLog); err != nil {
		job.im.infoLog.Printf("save(): failed to add save log output to store: %v", err)
	}

	job.Progress.set(StepSaving, 1)
	return nil
}
