\c postgres
drop database tank;
create database tank;
\c tank;
