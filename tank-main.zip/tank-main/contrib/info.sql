\c tank
\dt
select * from __migrations__;
\d shows;
\d files;
\d import_logs;
\d playlists;
\d playlist_entries;
