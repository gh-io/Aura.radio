//
//  tank, Import and Store Files for AURA
//  Copyright (C) 2017-2020 Christian Pointner <equinox@helsinki.at>
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Affero General Public License as
//  published by the Free Software Foundation, either version 3 of the
//  License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Affero General Public License for more details.
//
//  You should have received a copy of the GNU Affero General Public License
//  along with this program.  If not, see <https://www.gnu.org/licenses/>.
//

package v1

import (
	"gitlab.servus.at/autoradio/tank/importer"
	"net/http"

	"github.com/gin-gonic/gin"
)

// ListImportsOfShow returns a list of all running and pending imports for files belonging to a show if specified.
//
//	@Summary		List imports
//	@Description	Lists all running and pending imports
//	@Produce		json
//	@Param			showId	query		int	false	"ID of the show"
//	@Param			limit	query		int	false	"Limit number of results"
//	@Param			offset	query		int	false	"Start listing from offset"
//	@Success		200		{object}	JobsListing
//	@Failure		400		{object}	ErrorResponse
//	@Failure		403		{object}	ErrorResponse
//	@Failure		500		{object}	ErrorResponse
//	@Router			/api/v1/imports [get]
func (api *API) ListImportsOfShow(c *gin.Context) {
	var err error
	var jobs []*importer.Job
	var showIDs []uint64
	var showID uint64

	if showId := c.Query("showId"); showId != "" {
		if showID, err = idFromString(showId); err != nil {
			c.JSON(http.StatusBadRequest, ErrorResponse{Error: "invalid showId: " + err.Error()})
			return
		} else {
			if authorized, _ := authorizeRequestForShow(c, showID); !authorized {
				return
			}
		}
	} else {
		s := getAuthSession(c.Request)
		if s != nil {
			shows, err := api.store.ListShows()
			if err != nil {
				c.JSON(http.StatusInternalServerError, ErrorResponse{Error: err.Error()})
				return
			}
			for _, show := range shows {
				showIDs = append(showIDs, show.ID)
			}
		}
	}

	offset, limit, ok := getPaginationParameter(c)
	if !ok {
		return
	}

	if showID != 0 {
		jobs, err = api.importer.ListJobsForShows([]uint64{showID}, offset, limit)
	} else {
		jobs, err = api.importer.ListJobsForShows(showIDs, offset, limit)
	}

	if err != nil {
		sendError(c, err)
		return
	}

	if len(jobs) == 0 {
		jobs = make([]*importer.Job, 0)
	}

	c.JSON(http.StatusOK, JobsListing{jobs})
}

// ReadImportOfFile retrieves import status of the file.
//
//	@Summary		Retrieve import status
//	@Description	Retrieves import status of the file.
//	@Produce		json
//	@Param			showId	query		int		true	"ID of the show"
//	@Param			id		path		int		true	"ID of the file"
//	@Param			waitFor	query		string	false	"running|done - If given, return not before import has the given state"
//	@Success		200		{object}	importer.Job
//	@Failure		400		{object}	ErrorResponse
//	@Failure		403		{object}	ErrorResponse
//	@Failure		404		{object}	ErrorResponse	"No job for this file"
//	@Failure		500		{object}	ErrorResponse
//	@Router			/api/v1/files/{id}/import [get]
func (api *API) ReadImportOfFile(c *gin.Context) {
	showID, err := idFromString(c.Query("showId"))
	if err != nil {
		return
	}
	if authorized, _ := authorizeRequestForShow(c, showID); !authorized {
		return
	}

	id, err := idFromString(c.Param("file-id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, ErrorResponse{Error: "invalid file-id: " + err.Error()})
		return
	}

	waitFor := c.Query("waitFor")
	switch waitFor {
	case "running":
	case "done":
	case "":
	default:
		c.JSON(http.StatusBadRequest, ErrorResponse{Error: "unable to wait for unknown state: " + waitFor})
		return
	}

	job, err := api.importer.GetJob(showID, id)
	if err != nil {
		// TODO: return import info from store if err == ErrNotFound
		sendError(c, err)
		return
	}

	switch waitFor {
	case "running":
		<-job.Running()
	case "done":
		<-job.Done()
	}
	c.JSON(http.StatusOK, job)
}

// CancelImportOfFile cancels import of file.
//
//	@Summary		Cancel file import
//	@Description	Cancels import of file.
//	@Param			showId	query	int	true	"ID of the show"
//	@Param			id		path	int	true	"ID of the file"
//	@Success		204
//	@Failure		400	{object}	ErrorResponse
//	@Failure		403	{object}	ErrorResponse
//	@Failure		404	{object}	ErrorResponse	"No job for this file"
//	@Failure		500	{object}	ErrorResponse
//	@Router			/api/v1/files/{id}/import [delete]
func (api *API) CancelImportOfFile(c *gin.Context) {
	showID, err := idFromString(c.Query("showId"))
	if err != nil {
		return
	}

	if authorized, _ := authorizeRequestForShow(c, showID); !authorized {
		return
	}

	id, err := idFromString(c.Param("file-id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, ErrorResponse{Error: "invalid file-id: " + err.Error()})
		return
	}
	job, err := api.importer.GetJob(showID, id)
	if err != nil {
		sendError(c, err)
		return
	}
	job.Cancel()
	c.JSON(http.StatusNoContent, nil)
}
